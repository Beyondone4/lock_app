<template>
	<view class="container container15293">
		<view class="flex flex-wrap diygw-col-24 flex-direction-column flex2-clz">
			<view class="diygw-col-24 text5-clz diygw-text-lg"> 使用中的物品 </view>
			<view class="flex flex-wrap diygw-col-24 flex-direction-column flex3-clz">
				<view class="flex flex-wrap diygw-col-24 flex4-clz">
					<view class="diygw-col-0 text6-clz"> 物品 </view>
					<view class="diygw-col-0 text7-clz"> 规格 </view>
					<view class="diygw-col-0 text8-clz"> 数量 </view>
					<view class="diygw-col-0 text9-clz"> 操作 </view>
				</view>
				<view v-for="(item, index) in myassetsData.data.inuse" :key="index" class="flex flex-wrap diygw-col-24 flex5-clz">
					<view class="diygw-col-0 text10-clz">
						{{ item.storeArticleCn }}
					</view>
					<view class="diygw-col-0 text11-clz">
						{{ item.specs }}
					</view>
					<view class="diygw-col-0 text16-clz"> {{ item.num }}{{ item.unit }} </view>
					<view class="flex flex-wrap diygw-col-6 flex6-clz">
						<view @tap="navigateTo" data-type="clickReturnFunction" :data-index="index" class="diygw-col-0 text18-clz"> 回仓 </view>
						<view @tap="navigateTo" data-type="clickConsumedFunction" :data-index="index" class="diygw-col-0 text19-clz"> 消耗 </view>
					</view>
				</view>
			</view>
		</view>
		<view class="flex flex-wrap diygw-col-24 flex-direction-column flex9-clz">
			<view class="diygw-col-24 text17-clz diygw-text-lg"> 统计已使用 </view>
			<view class="flex flex-wrap diygw-col-24 flex-direction-column flex10-clz">
				<view class="flex flex-wrap diygw-col-24 flex11-clz">
					<view class="diygw-col-0 text20-clz"> 物品 </view>
					<view class="diygw-col-0 text21-clz"> 规格 </view>
					<view class="diygw-col-0 text22-clz"> 数量 </view>
					<view class="diygw-col-0 text23-clz"> 单位 </view>
				</view>
				<view v-for="(item, index) in myassetsData.data.count" :key="index" class="flex flex-wrap diygw-col-24 flex12-clz">
					<view class="diygw-col-0 text24-clz">
						{{ item.title }}
					</view>
					<view class="diygw-col-0 text25-clz">
						{{ item.specs }}
					</view>
					<view class="diygw-col-0 text26-clz">
						{{ item.num }}
					</view>
					<view class="diygw-col-0 text27-clz">
						{{ item.unit }}
					</view>
				</view>
			</view>
		</view>
		<view class="flex flex-wrap diygw-col-24 flex-direction-column flex-clz">
			<view class="diygw-col-24 text-clz diygw-text-lg"> 已消耗的物品 </view>
			<view class="flex flex-wrap diygw-col-24 flex-direction-column flex1-clz">
				<view class="flex flex-wrap diygw-col-24 flex7-clz">
					<view class="diygw-col-0 text1-clz"> 物品 </view>
					<view class="diygw-col-0 text2-clz"> 规格 </view>
					<view class="diygw-col-0 text3-clz"> 数量 </view>
					<view class="diygw-col-0 text4-clz"> 操作 </view>
				</view>
				<view v-for="(item, index) in myassetsData.data.consumed" :key="index" class="flex flex-wrap diygw-col-24 flex8-clz">
					<view class="diygw-col-0 text12-clz">
						{{ item.storeArticleCn }}
					</view>
					<view class="diygw-col-0 text13-clz">
						{{ item.specs }}
					</view>
					<view class="diygw-col-0 text14-clz"> {{ item.num }}{{ item.unit }} </view>
					<view class="diygw-col-0 text15-clz">
						{{ item.updateTime }}
					</view>
				</view>
			</view>
		</view>
		<view class="diygw-modal basic" :class="return" style="z-index: 1000000">
			<view class="diygw-dialog diygw-dialog-return basis-lg">
				<view class="justify-end diygw-bar">
					<view class="content"> 回仓 </view>
					<view class="action" data-type="closemodal" data-id="return" @tap="navigateTo">
						<i class="diy-icon-close"></i>
					</view>
				</view>
				<view>
					<view class="flex diygw-dialog-content">
						<view class="diygw-col-24 text28-clz"> 申请物品回仓之前，请先联系仓库管理员，取得授权之后再发起申请操作，否则仓管员有权拒绝接收，并且请保持回仓物品的完整与清洁 </view>
					</view>
				</view>
				<view class="flex justify-end">
					<button @tap="navigateTo" data-type="clickRseIntoDataApi" :data-id="globalData.storeflowid" class="diygw-btn green flex1 margin-xs">确认</button>
					<button data-type="closemodal" @tap="navigateTo" data-id="return" class="diygw-btn red flex1 margin-xs">关闭</button>
				</view>
			</view>
		</view>
		<view class="diygw-modal basic" :class="consumed" style="z-index: 1000000">
			<view class="diygw-dialog diygw-dialog-consumed basis-lg">
				<view class="justify-end diygw-bar">
					<view class="content"> 消耗 </view>
					<view class="action" data-type="closemodal" data-id="consumed" @tap="navigateTo">
						<i class="diy-icon-close"></i>
					</view>
				</view>
				<view>
					<view class="flex diygw-dialog-content">
						<view class="diygw-col-24 text29-clz"> 如果物品已经使用损耗（用完），或者丢失，请确认消耗！ </view>
					</view>
				</view>
				<view class="flex justify-end">
					<button @tap="navigateTo" data-type="clickConsumedDataApi" :data-id="globalData.storeflowid" class="diygw-btn green flex1 margin-xs">确认</button>
					<button data-type="closemodal" @tap="navigateTo" data-id="consumed" class="diygw-btn red flex1 margin-xs">取消</button>
				</view>
			</view>
		</view>
		<view class="clearfix"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//用户全局信息
				userInfo: {},
				//页面传参
				globalOption: {},
				//自定义全局变量
				globalData: { iduser: 0, storeflowid: 0 },
				myassetsData: {
					code: 0,
					msg: '',
					data: {
						count: [
							{
								num: 0,
								specs: '',
								title: '',
								unit: ''
							}
						],
						pending: [
							{
								id: 0,
								status: 0,
								num: 0,
								examine: '',
								img: null,
								remarks: '',
								title: '',
								specs: '',
								unit: '',
								idUser: 0,
								remarksBack: null,
								createTime: '',
								updateTime: '',
								deleteTime: null,
								projectCn: '',
								flowStatusCn: '',
								storeArticleCn: '',
								userCn: '',
								storeCn: '',
								examineCn: ''
							}
						],
						inuse: [
							{
								id: 0,
								status: 0,
								num: 0,
								examine: '',
								img: null,
								remarks: '',
								title: '',
								specs: '',
								unit: '',
								idUser: 0,
								remarksBack: null,
								createTime: '',
								updateTime: '',
								deleteTime: null,
								projectCn: '',
								flowStatusCn: '',
								storeArticleCn: '',
								userCn: '',
								storeCn: '',
								examineCn: ''
							}
						],
						consumed: [
							{
								id: 0,
								status: 0,
								num: 0,
								examine: '',
								img: null,
								remarks: '',
								title: '',
								specs: '',
								unit: '',
								idUser: 0,
								remarksBack: null,
								createTime: '',
								updateTime: '',
								deleteTime: null,
								projectCn: '',
								flowStatusCn: '',
								storeArticleCn: '',
								userCn: '',
								storeCn: '',
								examineCn: ''
							}
						]
					}
				},
				clickRseIntoData: {
					code: 500,
					msg: '回仓失败'
				},
				clickConsumedData: {
					code: 500,
					msg: '操作失败'
				},
				return: '',
				consumed: ''
			};
		},
		onShow() {
			this.setCurrentPage(this);
		},
		onLoad(option) {
			this.setCurrentPage(this);
			if (option) {
				this.setData({
					globalOption: this.getOption(option)
				});
			}

			this.init();
		},
		methods: {
			async init() {
				await this.getUserInfoFunction();
			},
			// 我名下的资产 API请求方法
			async myassetsDataApi(param) {
				let thiz = this;
				param = param || {};
				//请求地址及请求数据，可以在加载前执行上面增加自己的代码逻辑
				let http_url = 'bn/api.storeFlow/myassets';
				let http_data = {};
				let http_header = {};

				let myassetsData = await this.$http.post(http_url, http_data, http_header, 'json');

				this.myassetsData = myassetsData;
			},
			// 回仓 API请求方法
			async clickRseIntoDataApi(param) {
				let thiz = this;
				param = param || {};
				//请求地址及请求数据，可以在加载前执行上面增加自己的代码逻辑
				let http_url = 'bn/api.storeFlow/rseInto';
				let http_data = {
					id: param.id || this.globalData.storeflowid
				};
				let http_header = {};

				let clickRseIntoData = await this.$http.post(http_url, http_data, http_header, 'json');

				this.clickRseIntoData = clickRseIntoData;
				this.navigateTo({
					type: 'closemodal',
					id: 'return'
				});

				if (this.clickRseIntoData.code == 200) {
					this.navigateTo({
						type: 'tip',
						tip: '操作成功！'
					});
					await this.myassetsDataApi({});
				} else {
					this.navigateTo({
						type: 'tip',
						tip: '操作失败，请联系管理员！'
					});
				}
			},
			// 已消耗 API请求方法
			async clickConsumedDataApi(param) {
				let thiz = this;
				param = param || {};
				//请求地址及请求数据，可以在加载前执行上面增加自己的代码逻辑
				let http_url = 'bn/api.storeFlow/isConsumed';
				let http_data = {
					id: param.id || this.globalData.storeflowid
				};
				let http_header = {};

				let clickConsumedData = await this.$http.post(http_url, http_data, http_header, 'json');

				this.clickConsumedData = clickConsumedData;
				this.navigateTo({
					type: 'closemodal',
					id: 'consumed'
				});

				if (this.clickConsumedData.code == 200) {
					this.navigateTo({
						type: 'tip',
						tip: '操作成功！'
					});
					await this.myassetsDataApi({});
				} else {
					this.navigateTo({
						type: 'tip',
						tip: '操作失败，请联系管理员！'
					});
				}
			},

			// 获取用户信息（新） 自定义方法
			async getUserInfoFunction(param) {
				let thiz = this;
				let userinfo = this.$session.getUser();
				if (!this.$session.getUser()) {
					//比如未登录，转身到其他页面等
					this.showToast('请先登录');

					this.navigateTo({
						type: 'page',
						url: 'login'
					});
					return;
				} else {
					this.userInfo = userinfo;
					this.globalData.iduser = userinfo.id;
				}

				await this.myassetsDataApi({});
			},

			// 点击回仓按钮触发 自定义方法
			async clickReturnFunction(param) {
				let thiz = this;
				let index = param && (param.index || param.index == 0) ? param.index : thiz.index || '';
				//初始化
				this.globalData.storeflowid = 0;
				console.log(this.myassetsData.data.inuse);

				//正式赋值
				console.log(param.index);
				console.log(thiz.myassetsData.data.inuse);
				thiz.globalData.storeflowid = thiz.myassetsData.data.inuse[param.index].id;

				//打开弹窗
				thiz.navigateTo({
					type: 'openmodal',
					id: 'return'
				});
			},

			// 点击消耗按钮触发 自定义方法
			async clickConsumedFunction(param) {
				let thiz = this;
				let index = param && (param.index || param.index == 0) ? param.index : thiz.index || '';
				//初始化
				thiz.globalData.storeflowid = 0;
				console.log(thiz.myassetsData.data.inuse[param.index].id);

				//正式赋值
				thiz.globalData.storeflowid = thiz.myassetsData.data.inuse[param.index].id;

				//打开弹窗
				thiz.navigateTo({
					type: 'openmodal',
					id: 'consumed'
				});
			}
		}
	};
</script>

<style lang="scss" scoped>
	.flex2-clz {
		margin-left: 0px;
		width: 100% !important;
		margin-top: 20px;
		margin-bottom: 5px;
		margin-right: 0px;
	}
	.text5-clz {
		margin-left: 5px;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.flex3-clz {
		margin-left: 5px;
		border-top: 1px solid #b1b1b1;
		border-right: 1px solid #b1b1b1;
		border-left: 1px solid #b1b1b1;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.flex4-clz {
		background-color: #f6f6f6;
		border-bottom: 1px solid #b1b1b1;
	}
	.text6-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text7-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text8-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text9-clz {
		padding-top: 5px;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.flex5-clz {
		border-bottom: 1px solid #b1b1b1;
	}
	.text10-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text11-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text16-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text18-clz {
		padding-top: 5px;
		color: #00ff40;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text19-clz {
		padding-top: 5px;
		color: #f90101;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.flex9-clz {
		margin-left: 5px;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 20px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.text17-clz {
		margin-left: 5px;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.flex10-clz {
		margin-left: 5px;
		border-top: 1px solid #b1b1b1;
		border-right: 1px solid #b1b1b1;
		border-left: 1px solid #b1b1b1;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.flex11-clz {
		background-color: #f6f6f6;
		border-bottom: 1px solid #b1b1b1;
	}
	.text20-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text21-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text22-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text23-clz {
		padding-top: 5px;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.flex12-clz {
		border-bottom: 1px solid #b1b1b1;
	}
	.text24-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text25-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text26-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text27-clz {
		padding-top: 5px;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.flex-clz {
		margin-left: 0px;
		width: 100% !important;
		margin-top: 20px;
		margin-bottom: 5px;
		margin-right: 0px;
	}
	.text-clz {
		margin-left: 5px;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.flex1-clz {
		margin-left: 5px;
		border-top: 1px solid #b1b1b1;
		border-right: 1px solid #b1b1b1;
		border-left: 1px solid #b1b1b1;
		width: calc(100% - 5px - 5px) !important;
		margin-top: 5px;
		margin-bottom: 5px;
		margin-right: 5px;
	}
	.flex7-clz {
		background-color: #f6f6f6;
		border-bottom: 1px solid #b1b1b1;
	}
	.text1-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text2-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text3-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text4-clz {
		padding-top: 5px;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.flex8-clz {
		border-bottom: 1px solid #b1b1b1;
	}
	.text12-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text13-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text14-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.text15-clz {
		padding-top: 5px;
		border-right: 1px solid #b1b1b1;
		flex: 1;
		padding-left: 5px;
		padding-bottom: 5px;
		text-align: center;
		padding-right: 5px;
	}
	.return-clz {
		z-index: 1000000;
	}
	.diygw-dialog-return {
	}
	.text28-clz {
		padding-top: 5px;
		padding-left: 5px;
		font-size: 18px !important;
		padding-bottom: 5px;
		padding-right: 5px;
	}
	.consumed-clz {
		z-index: 1000000;
	}
	.diygw-dialog-consumed {
	}
	.text29-clz {
		padding-top: 5px;
		padding-left: 5px;
		font-size: 18px !important;
		padding-bottom: 5px;
		padding-right: 5px;
	}
	.container15293 {
		padding-left: 0px;
		padding-right: 0px;
	}
	.container15293 {
	}
</style>
