<template>
	<view class="container container15293">
		<view class="flex flex-wrap diygw-col-24 flex-direction-column flex6-clz">
			<view class="flex diygw-col-24 justify-around flex-nowrap white flex2-clz" @tap="navigateTo" data-type="page" data-url="/pages/null">
				<view class="flex flex-wrap diygw-col-6 flex-direction-column items-center flex1-clz" @tap="navigateTo" data-type="page" data-url="/pages/null">
					<view class="diygw-col-0 diygw-text-lg text-blue"> 0 </view>
					<view class="diygw-col-0 text-grey"> 待审批 </view>
				</view>
				<view class="flex flex-wrap diygw-col-6 flex-direction-column items-center flex4-clz">
					<view class="diygw-col-0 diygw-text-lg text-blue"> 0 </view>
					<view class="diygw-col-0 text-grey"> 会议提醒 </view>
				</view>
				<view class="flex flex-wrap diygw-col-6 flex-direction-column items-center flex3-clz">
					<view class="diygw-col-0 diygw-text-lg text-blue"> 0 </view>
					<view class="diygw-col-0 text-grey"> 周报 </view>
				</view>
				<view class="flex flex-wrap diygw-col-6 flex-direction-column items-center flex-clz">
					<view class="diygw-col-0 diygw-text-lg text-blue"> 0 </view>
					<view class="diygw-col-0 text-grey"> 工作汇报 </view>
				</view>
			</view>
			<view class="flex flex-wrap diygw-col-24 items-center flex8-clz" @tap="navigateTo" data-type="getUserInfoFunction">
				<image src="https://mjke.oss-cn-shenzhen.aliyuncs.com/bn/yh.png" class="image-size diygw-image diygw-col-0 image-clz" mode="widthFix"></image>
				<view class="flex flex-wrap diygw-col-0 flex-direction-column items-start flex9-clz">
					<view class="diygw-col-0 text1-clz">
						{{ this.userInfo.name }}
					</view>
					<view class="flex flex-wrap diygw-col-0 items-center flex10-clz">
						<view class="diygw-col-0"> 公司管理 </view>
					</view>
					<view class="flex flex-wrap diygw-col-0 items-center flex11-clz">
						<view class="diygw-col-0"> 电话：{{ this.userInfo.phone }} </view>
					</view>
				</view>
				<text class="flex icon diygw-col-0 icon-clz diy-icon-right"></text>
			</view>
			<view class="flex flex-wrap diygw-col-24 flex-direction-column white flex7-clz">
				<view class="diygw-title flex diygw-col-24">
					<view class="title font-normal"> 财务类 </view>
					<view class="more">
						<text class="diy-icon-right"></text>
					</view>
				</view>
				<view class="flex diygw-col-24">
					<view class="diygw-grid col-4">
						<view @tap="navigateTo" data-type="page" data-url="/pages/reimbursementAll" class="diygw-grid-item">
							<view class="diygw-grid-inner grid3-item-clz">
								<view class="diygw-grid-icon diygw-avatar grid3-icon-clz">
									<image mode="aspectFit" class="diygw-avatar-img" src="/static/clbxsq-01.png"></image>
								</view>
								<view class="diygw-grid-title"> 报销 </view>
							</view>
						</view>
					</view>
				</view>
			</view>
			<view v-if="globalData.isb == 1" class="flex flex-wrap diygw-col-24 flex-direction-column flex5-clz">
				<view class="flex flex-wrap diygw-col-24 flex-direction-column flex12-clz">
					<view class="diygw-title flex diygw-col-24">
						<view class="title font-normal"> BOSS端 </view>
					</view>
					<view class="flex diygw-col-24">
						<view class="diygw-grid col-4">
							<view @tap="navigateTo" data-type="page" data-url="/pages/boss/caiwu/gongcheng" class="diygw-grid-item">
								<view class="diygw-grid-inner grid4-item-clz">
									<view class="diygw-grid-icon diygw-avatar grid4-icon-clz diy-icon-all"> </view>
									<view class="diygw-grid-title"> 工程产值 </view>
								</view>
							</view>
							<view @tap="navigateTo" data-type="page" data-url="/pages/boss/caiwu/zhichu" class="diygw-grid-item">
								<view class="diygw-grid-inner grid4-item-clz">
									<view class="diygw-grid-icon diygw-avatar grid4-icon-clz diy-icon-rank"> </view>
									<view class="diygw-grid-title"> 财务支出 </view>
								</view>
							</view>
							<view @tap="navigateTo" data-type="page" data-url="/pages/boss/caiwu/fenxi" class="diygw-grid-item">
								<view class="diygw-grid-inner grid4-item-clz">
									<view class="diygw-grid-icon diygw-avatar grid4-icon-clz diy-icon-searchlist"> </view>
									<view class="diygw-grid-title"> 数据分析 </view>
								</view>
							</view>
							<view @tap="navigateTo" data-type="tip" data-tip="功能正在开发中... 敬请期待！" class="diygw-grid-item">
								<view class="diygw-grid-inner grid4-item-clz">
									<view class="diygw-grid-icon diygw-avatar grid4-icon-clz diy-icon-new"> </view>
									<view class="diygw-grid-title"> 意见反馈 </view>
								</view>
							</view>
							<view @tap="navigateTo" data-type="page" data-url="/pages/store/inventory" class="diygw-grid-item">
								<view class="diygw-grid-inner grid4-item-clz">
									<view class="diygw-grid-icon diygw-avatar grid4-icon-clz diy-icon-shop"> </view>
									<view class="diygw-grid-title"> 库存 </view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<view class="flex diygw-col-24">
			<button @tap="navigateTo" data-type="clearUserInfoFunction" class="diygw-btn red radius-xs flex-sub margin-xs button-button-clz">退出登录</button>
		</view>
		<view class="flex diygw-col-24">
			<button @tap="navigateTo" data-type="page" data-url="/pages/index" class="diygw-btn green radius-xs diygw-shadow flex-sub margin-lg button1-button-clz">返回首页</button>
		</view>
		<view class="clearfix"></view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				//用户全局信息
				userInfo: {},
				//页面传参
				globalOption: {},
				//自定义全局变量
				globalData: { isb: 0 }
			};
		},
		onShow() {
			this.setCurrentPage(this);
		},
		onLoad(option) {
			this.setCurrentPage(this);
			if (option) {
				this.setData({
					globalOption: this.getOption(option)
				});
			}

			this.init();
		},
		methods: {
			async init() {
				await this.getUserInfoFunction();
			},
			// 获取用户信息（新） 自定义方法
			async getUserInfoFunction(param) {
				let thiz = this;
				let userinfo = this.$session.getUser();
				if (!this.$session.getUser()) {
					//比如未登录，转身到其他页面等
					this.showToast('请先登录');

					this.navigateTo({
						type: 'page',
						url: 'login'
					});
					return;
				} else {
					this.userInfo = userinfo;
					if (userinfo.role == 2) {
						this.globalData.isb = 1;
					} else {
						this.globalData.isb = 0;
					}
				}
			},

			// 清除用户登录信息（新） 自定义方法
			async clearUserInfoFunction(param) {
				let thiz = this;
				let clear = uni.clearStorage();
				console.log(clear);

				if (!this.$session.getUser()) {
					//比如未登录，转身到其他页面等
					this.showToast('退出成功');
					this.navigateTo({
						type: 'page',
						url: 'login'
					});
					return;
				} else {
					let userinfo = this.$session.getUser();
					this.userInfo = userinfo;
					if (userinfo.role == 2) {
						this.globalData.isb = 1;
					} else {
						this.globalData.isb = 0;
					}
				}
			}
		}
	};
</script>

<style lang="scss" scoped>
	.flex6-clz {
		margin-left: 0px;
		z-index: 100;
		background-repeat: no-repeat;
		background-size: contain;
		width: 100% !important;
		margin-top: 0px;
		background-image: url(https://YourWebsite.cn/static/OA.png);
		margin-bottom: 30px;
		margin-right: 0px;
	}
	.flex2-clz {
		padding-top: 20px;
		border-bottom-left-radius: 10px;
		z-index: 100;
		padding-left: 10px;
		padding-bottom: 20px;
		border-top-right-radius: 10px;
		margin-right: 10px;
		background-color: rgba(217, 217, 217, 0.13);
		margin-left: 10px;
		box-shadow: 0px 2px 4px 3px rgba(181, 207, 255, 0.5);
		overflow: hidden;
		width: calc(100% - 10px - 10px) !important;
		border-top-left-radius: 10px;
		margin-top: 120px;
		border-bottom-right-radius: 10px;
		margin-bottom: 10px;
		padding-right: 10px;
	}
	.flex1-clz {
		z-index: 100;
		border-right: 1px solid #eee;
	}
	.flex4-clz {
		z-index: 100;
		border-right: 1px solid #eee;
	}
	.flex3-clz {
		z-index: 100;
		border-right: 1px solid #eee;
	}
	.flex-clz {
		z-index: 100;
		border-right: 1px solid #eee;
	}
	.flex8-clz {
		margin-left: 10px;
		width: calc(100% - 10px - 10px) !important;
		margin-top: 10px;
		margin-bottom: 0px;
		margin-right: 10px;
	}
	.image-clz {
		margin-left: 5px;
		border: 1px solid rgba(240, 240, 240, 0.17);
		border-bottom-left-radius: 30px;
		box-shadow: 0px 1px 3px rgba(242, 242, 242, 0.49);
		overflow: hidden;
		border-top-left-radius: 30px;
		margin-top: 0px;
		border-top-right-radius: 30px;
		border-bottom-right-radius: 30px;
		margin-bottom: 0px;
		margin-right: 5px;
	}
	.image-size {
		height: 50px !important;
		width: 50px !important;
	}
	.flex9-clz {
		flex: 1;
	}
	.text1-clz {
		margin-left: 0px;
		font-weight: bold;
		font-size: 16px !important;
		margin-top: 0px;
		margin-bottom: 5px;
		text-align: center;
		margin-right: 0px;
	}
	.flex10-clz {
		background-color: #dbe4e9;
		padding-top: 0px;
		border-bottom-left-radius: 20px;
		overflow: hidden;
		padding-left: 0px;
		padding-bottom: 0px;
		border-top-left-radius: 20px;
		border-top-right-radius: 20px;
		border-bottom-right-radius: 20px;
		padding-right: 3px;
	}
	.flex11-clz {
		background-color: #dbe4e9;
		padding-top: 0px;
		border-bottom-left-radius: 20px;
		overflow: hidden;
		padding-left: 0px;
		padding-bottom: 0px;
		border-top-left-radius: 20px;
		border-top-right-radius: 20px;
		border-bottom-right-radius: 20px;
		padding-right: 3px;
	}
	.icon-clz {
		color: #979797;
	}
	.icon {
		font-size: 17px;
	}
	.flex7-clz {
		border-bottom-left-radius: 10px;
		z-index: 100;
		border-top-right-radius: 10px;
		margin-right: 10px;
		background-color: rgba(217, 217, 217, 0.13);
		margin-left: 10px;
		box-shadow: 0px 2px 4px 3px rgba(181, 207, 255, 0.5);
		overflow: hidden;
		width: calc(100% - 10px - 10px) !important;
		border-top-left-radius: 10px;
		margin-top: 10px;
		border-bottom-right-radius: 10px;
		margin-bottom: 10px;
	}
	.grid3-item-clz {
		margin: 0px;
		padding: 10px;
	}
	.grid3-icon-clz {
		font-size: calc(30px - 4px) !important;

		width: 30px;
		height: 30px;
	}
	.flex5-clz {
		margin-left: 15px;
		border-bottom-left-radius: 10px;
		box-shadow: 0px 1px 3px 2px rgba(149, 149, 149, 0.26);
		z-index: 1000;
		overflow: hidden;
		width: calc(100% - 15px - 15px) !important;
		border-top-left-radius: 10px;
		margin-top: 8px;
		border-top-right-radius: 10px;
		border-bottom-right-radius: 10px;
		margin-bottom: 8px;
		margin-right: 15px;
	}
	.grid4-item-clz {
		margin: 0px;
		padding: 10px;
	}
	.grid4-icon-clz {
		font-size: calc(40px - 4px) !important;

		width: 40px;
		height: 40px;
	}
	.button-button-clz {
		margin: 3px !important;
	}
	.button1-button-clz {
		margin: 3px !important;
	}
	.container15293 {
		padding-left: 0px;
		padding-right: 0px;

		background-position: top center;
		background-size: contain;
		background-repeat: no-repeat;
	}
	.container15293 {
	}
</style>
