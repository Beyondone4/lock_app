<script>
	export default {
		globalData: {
			userInfo: null,
			tabBar: ['/pages/index', '/pages/login', '/pages/reimbursementAll', '/pages/personal'],
			homePage: '/pages/index',
			pages: ['/pages/index', '/pages/register', '/pages/login', '/pages/human/roster', '/pages/personal', '/pages/reimbursementAll', '/pages/output', '/pages/output/listshow', '/pages/finance/reimbursement/personalRecords', '/pages/finance/enterprise/reconciliation', '/pages/boss/caiwu/zhichu', '/pages/boss/caiwu/gongcheng', '/pages/boss/caiwu/fenxi'],
			userData: {}
		}
	};
</script>
<style lang="scss">
	@import 'common/diygw-ui/iconfont.scss';
	@import 'common/diygw-ui/animate.css';
	@import 'common/diygw-ui/index.scss';

	@import './uni_modules/diy-uview-ui/index.scss';
	@import 'common/diygw-ui/uview.scss';
</style>
