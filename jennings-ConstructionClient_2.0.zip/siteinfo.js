//网址，公司名称
export default {
    basePath: 'https://xx.xxx.cn',
    fileBasePath: 'https://xx.xx.cn',
    title: 'XXX公司',
    debug: false,
    appid:'15293'
}
